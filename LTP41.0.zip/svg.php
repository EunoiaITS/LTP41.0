<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="40" width="40">
	<g transform="translate(16.5,16.5)">
		<rect id="rounded-rectangle" x="0" y="0" height="32" width="32" stroke="#000" rx="0" stroke-width="1" fill="#000" />
	</g>
</svg>