<?php
    $page = 'faq';
    include('index.php');