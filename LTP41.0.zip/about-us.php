<?php
    $page = 'about-us';
    include('index.php');