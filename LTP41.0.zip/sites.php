<?php
    $page = 'sites';
    include('index.php');