<?php
    $page = 'contact';
    include('index.php');