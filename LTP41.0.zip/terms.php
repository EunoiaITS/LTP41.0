<?php
    $page = 'terms';
    include('index.php');