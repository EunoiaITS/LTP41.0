<div class="about-us clearfix">
    <div class="container">
        <div class="about-anbonaki clearfix">
            <div class="col-sm-10 no-padding-left">
                <h2>ABOUT ANBONAKI</h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ornare eros vitae elit rutrum ornare. Nunc iaculis tellus vitae nulla iaculis, ac semper magna molestie. Quisque hendrerit elit augue, quis porta sem consequat mattis. Sed nec urna imperdiet, dictum ex sollicitudin, pellentesque diam. Aliquam tincidunt ultrices enim, non hendrerit justo. Pellentesque sit amet dui a urna elementum imperdiet. Suspendisse vitae ex vel erat blandit posuere. Pellentesque ac mi nec mi aliquet lacinia. Interdum et malesuada fames ac ante ipsum primis in faucibus. Sed quis iaculis massa, quis vestibulum neque. Curabitur non sapien erat.</p>

                <p>Proin pharetra magna ut euismod facilisis. Pellentesque vel purus vehicula, sodales enim quis, aliquet nibh. Mauris quis commodo tortor. Vivamus varius mollis lectus, vitae aliquet erat sodales ut. Praesent nec augue diam. Donec blandit ut magna eu placerat. Cras vitae turpis id orci ultricies blandit ut sit amet sapien. Suspendisse aliquet turpis vehicula nunc ultrices vestibulum.</p>

                <p>Aenean facilisis sapien at magna sagittis vehicula. Maecenas leo sapien, pellentesque eu mauris ut, cursus placerat nibh. Sed scelerisque ut nisi non blandit. Donec eu quam rutrum, faucibus lectus sit amet, bibendum elit. Donec maximus lacus dui, nec sodales lectus vestibulum eget. Cras eget ante non justo tristique interdum. Mauris eget rhoncus neque.</p>

                <p>Quisque nec lacinia nulla, ut mattis dui. In consectetur sodales nunc. Nunc vel nibh convallis, egestas lorem vel, auctor lorem. Fusce tortor mi, euismod in ipsum at, rutrum tempor tellus. Mauris sollicitudin felis metus, sit amet consequat sem placerat a. Mauris tincidunt odio vitae quam efficitur, non iaculis nisl placerat. Vivamus eget congue libero. Nam porta neque purus, in dignissim sapien rhoncus id. Vivamus placerat blandit posuere. Quisque ac urna quis sem bibendum dictum.</p>

                <p>Sed laoreet, turpis non congue viverra, erat nisl pharetra arcu, eu vestibulum ante ex id nunc. Nam pulvinar et tortor quis tristique. Quisque congue urna sed eleifend rutrum. Integer eu auctor lorem. Duis porta, arcu et interdum consectetur, est tellus ultricies nisl, ac fermentum lacus libero dictum quam. Maecenas et leo sem. Integer accumsan justo eu fringilla congue. Vestibulum auctor facilisis libero, et euismod elit consectetur at. Donec in felis ut elit lacinia vulputate. Vestibulum viverra justo sapien, eleifend laoreet mauris ornare ut. Sed non turpis nec odio luctus scelerisque. Maecenas ultricies eu metus id eleifend. Morbi posuere metus et ex faucibus, ut facilisis sem lobortis.</p>
            </div>
            <div class="col-sm-2">
                <img src="img/about-us-logo.png" class="about-logo" alt="anbonaki logo">
            </div>
            <div class="divider-lin clearfix">
                <img src="img/line-bg.png" alt="divider line">
            </div>
            <div class="gallery-img">
                <div class="col-sm-4">
                    <img src="img/img-1.jpg" alt="image 1">
                </div>
                <div class="col-sm-4">
                    <img src="img/img-2.jpg" alt="image 1">
                </div>
                <div class="col-sm-4 galley-last">
                    <img src="img/img-3.jpg" alt="image 1">
                </div>
            </div>
        </div>
    </div>
</div>